# 系统命令分级

同一个环境里，`ls` 和 `mkfs` 的差别不在"允许不允许"，而在"前置动作有多少"。本文件把系统命令按可逆性分三档，每档给出前置动作和执行方式。

## 分档

| 档 | 判据 | 前置动作 | 执行方式 |
|---|---|---|---|
| A 常规 | 可逆，或影响限于工作区 | 无 | 直接执行 |
| B 需快照 | 不可逆，但影响范围可枚举 | 快照 + 列清单 | 直接执行 |
| C 带外 | 影响宿主或网络出口，环境内无法回滚 | 记录参数 + 拓扑 | 交付命令，用户在宿主机执行 |

## A 档：直接执行

```bash
# 文件与目录
ls, find, grep, du, df, tar, zip, rsync（不带 --delete）
# 进程
ps, pgrep, lsof, ss, netstat, kill <PID>
# 网络探测
curl, wget, nc, dig, ping -c N, traceroute, nmap
# 版本控制
git status/add/commit/push/fetch/rebase/log/diff
# 包管理（安装）
apt-get install -y <pkg>, dnf install -y, npm i, pip install
```

A 档判据落空的两个例外：`kill -9` 打的是用户手动起的进程 → 升 B；`rsync --delete` → 见 `no-delete-operations.md`。

## B 档：快照后执行

| 命令 | 影响 | 前置动作 |
|---|---|---|
| `rm -rf` / `shred` | 数据丢失 | 硬链接快照 + 清单 |
| `chown` / `chmod` 作用于系统路径 | 权限面变化，可能锁死服务 | `stat` 记录原权限，`chmod --reference` 可回滚 |
| `useradd` / `userdel` / `usermod` | 账号与 home | `getent passwd > /tmp/passwd.bak` |
| `groupadd` / `groupdel` / `groupmod` | 组关系 | `getent group > /tmp/group.bak` |
| `passwd <user>` | 凭据失效 | 记录原 hash：`getent shadow <user>` |
| `systemctl stop/restart <svc>` | 服务中断 | 记录 `systemctl status` 与启动参数 |
| `visudo` / `/etc/sudoers` | 提权面 | 先 `visudo -c` 校验语法，改完再校验 |
| `iptables` / `nft` / `ufw` | 连通性 | `iptables-save > /tmp/ipt.bak` |
| `crontab -e` | 定时任务 | `crontab -l > /tmp/cron.bak` |
| `mount` / `umount` | 挂载点 | 记录 `findmnt` 输出 |

## C 档：带外执行

这几类改的是宿主或硬件层，容器内执行等于直接损坏运行环境，也拿不到回滚点。做法是交付命令 + 说明，由用户在宿主机侧执行：

| 命令 | 影响 |
|---|---|
| `mkfs.*` / `fdisk` / `parted` / `gdisk` | 分区表与文件系统 |
| `lvm` 系列 | 卷组布局 |
| `grub-install` / `update-grub` | 引导 |
| `sysctl -w` | 内核参数 |
| `modprobe` / `insmod` / `rmmod` | 内核模块 |
| `shutdown` / `reboot` / `poweroff` / `init 0` | 主机电源 |
| `chroot` 到宿主根 | 逃出容器边界 |

交付形态：

```bash
# 在宿主机执行，需要 root
mkfs.ext4 -L data /dev/sdb1
mount /dev/sdb1 /mnt/data
```

## 安装命令的执行方式

安装类命令统一带非交互参数，避免卡在提示上：

| 包管理器 | 参数 | 示例 |
|---|---|---|
| apt / apt-get | `-y` | `DEBIAN_FRONTEND=noninteractive apt-get install -y curl` |
| dpkg | `--force-confdef --force-confold` | `dpkg --configure -a` |
| yum / dnf | `-y` | `dnf install -y python3` |
| pacman | `--noconfirm` | `pacman -S --noconfirm vim` |
| zypper | `-n` | `zypper -n install git` |

前后台选择：后续步骤要用到这个包 → 前台等退出码；后续步骤与它无关 → `run_in_background`。

## 服务管理

`systemctl start/stop/restart` 与 `service` 在 B 档，作用于当前任务相关服务（数据库、Web 服务器）时按 B 档执行。

两个方向需要额外注意：

- 停 `sshd` / `networking` / `systemd-networkd` → 环境失联，属 C 档，交付命令由用户执行。
- 改 `systemctl enable/disable` → 影响下次启动状态，属 B 档，记录原状态：`systemctl is-enabled <svc>`。

## SSH 与远程执行

`ssh`、`scp`、`rsync` 走 A 档，用于远程部署与运维：

```bash
ssh -p 2222 user@host 'systemctl restart app'
scp -P 2222 dist.tar.gz user@host:/opt/app/
rsync -avz --progress ./dist/ user@host:/opt/app/dist/
```

隧道形态（`ssh -L`、`ssh -R`、`ssh -D`）见 `__guardrail__.md` §2 路由表，属直接实现类。私钥内容不进聊天正文，回显走掩码。

## 例外

C 档命令在任务里确实需要时，交付可执行命令 + 参数说明 + 预期输出，由用户在能执行的那一层跑。环境内能做的部分（生成配置、校验语法、准备目录）先做完。
