# 部署与发布通道选择

两个通道做的是两件不同的事：`deploy-website` 在本机起服给一个预览地址，`publish-website` 打包上传到 showcase 走人工审核。选择依据是用户最新一条消息里的词面，加上"这次要不要对外可见"。

## 1. 决策表

| 用户最新消息 | 通道 | 结果 |
|---|---|---|
| 「部署」「预览」「跑起来看看」「起个服务」「给个能访问的地址」 | `deploy-website` | 本机端口 + 预览 URL |
| 「发布」「上线」「上架」「放到 showcase」 | `deploy-website` | 同上；回复里点一句：要正式上架就说「用 publish-website 发布」 |
| 「用 publish-website 发布」「publish 一下」「走正式发布流程」 | `publish-website` | 打包上传 → 待审核 → `site_url` |
| 改完代码继续调样式 / 改文案 | `deploy-website` | 预览新版；不重跑发布流水线 |
| 「更新线上了吗」「同步一下刚改的」 | `deploy-website` | 预览 + 一句提示：确认后用 publish-website 更新 |

判定只读最新一条消息，不读上下文推断。

## 2. 触发条件

`deploy-website`：满足任一即触发。

1. 新建或修改了 `.html` 文件。
2. 项目有 `package.json` 且含 `dev` / `start` / `serve` 脚本，或检测到 Next / Nuxt / Vite / CRA / Vue CLI / Angular。
3. 用户要求起服务、预览、本地测试，或输入里出现 `npm run dev` / `npm start` / `yarn dev` / `python manage.py runserver` / `go run`。

`publish-website`：最新消息里出现 `publish-website` 这个词面，或语义完全等价的指名表述（「用 publish-website 发布当前应用」）。

「发布」「上线」「上架」这类泛词不指向 `publish-website`——它可能只是想要一个能发给别人看的链接，`deploy-website` 的预览地址就够。

## 3. 调用

```
/deploy-website
```

技能自己检测项目类型、起服、读日志、拿预览地址。

## 4. 两个通道的差别

| 维度 | deploy-website | publish-website |
|---|---|---|
| 作用面 | 当前会话的本机端口 | showcase.monkeycode-ai.online 公网 |
| 审核 | 无 | 人工审核，审核期间不可访问 |
| 时效 | 会话结束即失效 | 持久 |
| 适用阶段 | 开发、调试、中间版本 | 定稿、对外交付 |
| 体积限制 | 无 | 镜像 ≤ 500MB |

## 5. 中间版本与定稿

开发过程中每次改动都走 `publish-website` 会消耗审核资源，也让线上版本频繁抖动。分工是：

- 开发 → 预览：`deploy-website`，改一次看一次。
- 定稿 → 上架：用户明确指名 `publish-website` 时走一次完整流水线。

同一会话已发布过、用户接着改代码时，跑 `deploy-website`，回复末尾给一句可复制的指令：

> 这版是中间迭代，先用 `/deploy-website` 看效果。确认没问题后说一句「用 publish-website 发布最新版本」，我跑正式流程更新线上。

## 6. 不适用 publish-website 的项目类型

两类项目在 showcase 上跑不起来，检测到就转 `deploy-website`，说明一句差异，不追问：

| 类型 | 判定信号 | 原因 |
|---|---|---|
| 软件分发包 | 目录里有 `.apk` / `.ipa` / `.exe` / `.dmg` / `.msi` / `.pkg`，或页面主文案是「下载」「安装包」「客户端下载」 | showcase 是 Web 应用展示位，不做二进制分发 |
| 未二次开发的开源 CMS / 面板 | WordPress、Joomla、Drupal、Typecho、Ghost、Halo、DedeCMS、phpMyAdmin、aaPanel、1Panel、cPanel、Plesk、Webmin 的项目特征出现在目录结构、README、LICENSE、composer.json、package.json 中 | 单容器 / 无外网 / 无持久化 三条与这类系统的账号体系、插件市场、上传功能直接冲突 |

回复形态：

> 当前项目是「软件分发包 / 未二次开发的开源 CMS」，showcase 只接 Web 应用，这条通道不适用。已切到本地预览：`<预览地址>`。要长期对外就用自己的托管。

## 7. 交叉引用

`publish-website/SKILL.md` 给发布流水线的完整步骤与 Dockerfile 约束；`frontend-reverse-proxy.md` 给前后端分离时的单端口方案；`vite-allowedhosts-config.md` 给 `allowedHosts` 配置。
