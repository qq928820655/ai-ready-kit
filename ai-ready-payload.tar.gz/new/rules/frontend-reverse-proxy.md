# Frontend Reverse Proxy Rule

When implementing a frontend-backend separated web application, always configure a reverse proxy in the frontend to forward API requests to the backend server.

## Background

The current online preview environment can only expose a single port. Therefore, when developing applications with separate frontend and backend services, the frontend must include a reverse proxy configuration to route API requests to the backend.

## Guidelines

When implementing a frontend for a web application with a separate backend:

1. **Configure reverse proxy**: Set up a proxy in the frontend development server to forward API requests to the backend
2. **Use consistent API prefix**: Typically use `/api` as the prefix for backend requests
3. **Ensure both services start**: The preview should start both frontend and backend services

## Implementation by Framework

### Vite (Vue, React, etc.)

In `vite.config.ts` or `vite.config.js`:

```typescript
export default defineConfig({
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:3001', // Backend server address
        changeOrigin: true,
        // rewrite: (path) => path.replace(/^\/api/, '') // Optional: remove /api prefix
      }
    }
  }
})
```

### Create React App

In `package.json`:

```json
{
  "proxy": "http://localhost:3001"
}
```

Or use `src/setupProxy.js` for more control:

```javascript
const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function(app) {
  app.use('/api', createProxyMiddleware({
    target: 'http://localhost:3001',
    changeOrigin: true,
  }));
};
```

### Next.js

In `next.config.js`:

```javascript
module.exports = {
  async rewrites() {
    return [
      {
        source: '/api/:path*',
        destination: 'http://localhost:3001/api/:path*',
      },
    ];
  },
};
```

### Webpack Dev Server

In `webpack.config.js`:

```javascript
module.exports = {
  devServer: {
    proxy: {
      '/api': {
        target: 'http://localhost:3001',
        changeOrigin: true,
      },
    },
  },
};
```

## Startup Script

Create a startup script that runs both services. Example `start.sh`:

```bash
#!/bin/bash
# 后端先起，记 PID 供退出时清理
cd backend && npm run dev &
BACKEND_PID=$!

# 前端占用对外端口
cd ../frontend && npm run dev &
FRONTEND_PID=$!

# 任一退出就带走另一个，避免残留进程占端口
trap 'kill "$BACKEND_PID" "$FRONTEND_PID" 2>/dev/null' EXIT
wait -n
```

原版本里 `BACKEND_PID=` 是空赋值、`trap "kill "` 没有目标，退出时后端不会被回收，下次起服撞端口。

## Rationale

- Online preview environment only exposes one port to the user
- The frontend development server port is typically the one exposed for preview
- Reverse proxy allows API requests to reach the backend without CORS issues
- This setup mimics production deployment where a single entry point handles all requests
