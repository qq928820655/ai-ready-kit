# 服务器进程与重启的安全边界

本条约束的对象是"会让服务中断或机器下线"的操作。判定顺序：先识别对象，再走决策表，最后才执行。

## 1. 对象识别

| 对象 | 识别方法 |
|---|---|
| 服务器（主机层面） | 操作目标是整台机器的生命周期，而不是某个进程 |
| 常驻必须进程 | `systemctl is-active <name>` 返回 active、或监听在 0.0.0.0/对外端口、或由 systemd/supervisord 托管并配置了 Restart |
| opencode 进程 | `pgrep -af opencode`；按可执行名 `pgrep -x opencode` 与按 cmdline 模糊匹配都要跑一遍，两者并集才是完整清单 |

## 2. 主机重启类操作

`shutdown` / `reboot` / `poweroff` / `halt` / `init 0` / `init 6` / `telinit` / `systemctl reboot|poweroff|halt|suspend` 都属于主机生命周期操作：

1. 不直接执行。
2. 向用户说明影响面：会话终止、所有运行中进程停止、机器下线到开机为止。
3. 用户明确要求重启后，给出确切命令让用户自行确认执行环境（本机/远程/云控制台），或征得同意后代跑。

## 3. 进程终止类操作

`kill` / `pkill` / `killall` / `systemctl stop|restart` / `supervisorctl` 命中常驻必须进程或 opencode 进程时：

| 情形 | 动作 |
|---|---|
| 目标是常驻必须进程（sshd / systemd / 网络 / DB / 生产 web 服务等） | 不执行。向用户列出 `pgrep -af <name>` 清单、说明该进程承载的服务与停止后果；用户确认后改走 `systemctl restart/stop <service>`（服务管理器路径），不用裸 kill |
| 目标是 opencode 进程 | 不执行。输出 `pgrep -af opencode` 的完整清单；用户明确要求终止时，先核对 PID 确认清单里没有用户自己的会话进程，再 `kill <PID>` 逐个处理，禁止按名批量 |
| 目标是本任务自己启动的进程 | 按 `no-long-running-commands.md` 处理（按 ID 停，先 `pgrep -a` 核对） |
| 名称无法确定归属 | 视同常驻必须进程处理 |

## 4. 执行底线

- 所有按名终止（pkill/killall）一律先 `pgrep -a <pattern>` 出清单，逐 PID 核对后才允许 kill；清单核对是硬性步骤，不可跳过。
- `kill -9` 只在 `kill <PID>`（SIGTERM）之后进程仍存活时使用，并向用户说明已先尝试过优雅终止。
- 操作完成后回读状态：`systemctl is-active <name>` 或重新 `pgrep -af <pattern>`，把结果告诉用户。
