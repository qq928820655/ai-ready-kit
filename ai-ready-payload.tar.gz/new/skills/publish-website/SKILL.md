---
name: publish-website
description: Publishes a Web project generated in the current session as an online hosted application. Handles environment information retrieval, project type detection, frontend builds (reusing the detection rules from deploy-website), automatic metadata generation based on application content, static asset packaging, and upload to the showcase API through a multipart form POST. Supports purely static projects, Node.js frontends, and containerized backend projects.
arguments:
  - name: workspace
    description: Absolute path of the project to publish; defaults to the current working directory
    required: false
---

# Publish Application (Publish Website)

Publish a frontend-only project or a containerized project with a backend as an online application. This Skill runs as a fixed pipeline: steps execute in order, each step's output feeding the next; success is reported after Step 8 returns 2xx and `data.site_url` is non-empty.

## 触发判定（本流水线处理正式发布）

`publish-website` 是面向公开展示位的正式发布通道，每次执行会占用审核资源并把站点对外可见。触发依据是用户**最新一条消息**里的词面；没有指名本技能时，走 `deploy-website` 本地部署 + 平台在线预览。

### 触发词面

1. 最新消息里出现 `publish-website` 技能名，或语义等价的指名表述（「用 publish-website 发布」「publish 一下」「走正式发布流程」）
2. 该表述由用户自己给出，不是本技能或模型在对话中提议后用户点头的结果（模型提议「要不要发布」得到的肯定答复，走 `deploy-website`）

### 重复触发判定

同一会话已成功发布过一次，最新消息只是继续调代码、修 bug、改文案、调样式时，走预览分支：

- **不要**因为「之前发布过」就再跑一遍流水线
- **不要**把「代码更新了」「内容变了」「顺便再发一次」当成重跑理由
- 开发期的中间版本验证统一走 `deploy-website` 本地部署 + 平台在线预览

### 预览分支的动作

判定为重复触发时，不进发布流水线，改为：

1. 回复里说明：「这版是中间迭代，先用 `/deploy-website` 在平台内预览确认。满意后说一句『用 publish-website 发布最新版本』，我跑正式流程更新线上。」
2. 按需调用 `/deploy-website` 完成本地部署与预览
3. 本流水线在此收束

## Pipeline Overview

1. Retrieve environment information (`client_id`)
2. Detect the project type and automatically determine `kind` (static / backend) (reuse `deploy-website` detection rules; backend coverage includes Node-Express, FastAPI, Django+gunicorn, Spring Boot jar, Go, Rust, and others)
3. Route to the static or backend sub-pipeline according to the result
4. Prepare the artifact:
   - static branch: build the frontend when necessary and prepare the static artifact
   - backend branch (Step 3b): generate the Dockerfile, build, run, healthcheck, and save the image
5. Automatically generate the application name and description from its content, confirm each with the user, and ask for the application author
6. Package as `/tmp/dist.zip` (static branch) or confirm `/tmp/showcase-image.tar.gz` (backend branch)
7. Determine the `ticket` (on the first submission, ask whether to reuse an existing application)
8. POST the artifact to the showcase API as a multipart form, cache the returned `ticket`, and return the `site_url` to the user

Server-side registration and administrator review occur **after** Skill execution ends and are outside this Skill's responsibilities.

### About `ticket` (Application Update Key)

- `ticket` is the credential the showcase service uses to identify "the same application." Initial creation issues a `ticket`; to **update** that application later rather than create a new one, include the same `ticket` in the request body
- **会话级缓存**：本会话首次创建成功后拿到的 `ticket` 缓存进会话上下文（内存/笔记即可）；同会话后续提交自动复用该 `ticket`，不再向用户重复询问
- Only when **no application has ever been submitted in this session** should the user be asked whether to reuse an application created in another task (Step 7a)
- **Cross-kind switching**: the same `ticket` can switch from `static` to `backend` (or vice versa). The server replaces the original application in full with the new kind and returns it to pending review; during user confirmation, explicitly state: "This will switch the original application from X to Y and return it to pending review"

---

## Step 1 - Retrieve Environment Information

Run the `hostname` command to obtain the current hostname for use as `client_id` in the subsequent upload request:

```bash
hostname
```

Record the output string exactly as `client_id`. **Do not** fabricate it or use another value; if the command fails, terminate and report the failure to the user.

---

## Step 1b - 通道适用性预检（运行时约束）

判定 `kind` 之前，先看当前工作目录是否属于下面两类「本通道不接」的项目。命中任一项时，切到 `deploy-website` 本地预览，回复里说明一句通道差异，本流水线在此收束。

### 本通道不接的项目类型

1. **Software download/distribution sites**: sites whose primary purpose is to provide downloads of executable installers such as `.apk` / `.ipa` / `.exe` / `.dmg` / `.msi` / `.pkg`
   - Detection signals: binary files with the extensions above exist in the site directory, or page copy prominently advertises "Download," "Installer," "Client Download," "Download APK / IPA / EXE / DMG," and similar wording
   - Reason: showcase 是 Web 应用展示位，二进制分发与分发链路的托管不在其中
2. **Direct publication of open-source CMS / website panel projects**: an open-source site-building system or operations panel published directly without any secondary development
   - Common characteristics include but are not limited to: WordPress, Joomla, Drupal, Typecho, Ghost, Halo, DedeCMS, Empire CMS, DEDECMS, PHPMyAdmin, aaPanel, 1Panel, cPanel, Plesk, Webmin, and others
   - Detection signals: the project names above appear in the directory structure, `readme`, `LICENSE`, `composer.json`, or `package.json`, or the homepage is clearly one of these systems' default admin panels/installers
   - Reason: these projects are themselves general-purpose platforms, so direct publication does not constitute a "user work." They also commonly include account systems, file uploads, and plugin marketplaces that seriously conflict with the "single container / no external network / no persistence / publicly visible" runtime constraints

### 匹配时的动作

命中时回复用户：

> 当前项目是「软件分发包 / 未二次开发的开源 CMS 或面板」，showcase 只接 Web 应用，这条通道不适用。已切到本地预览：`<预览地址>`。要长期对外就用自己的托管。

随后跑 `/deploy-website` 出预览地址，本流水线结束。

---

## Step 2 - Automatically Determine `kind` (static / backend)

The Skill automatically determines the publication `kind` **by scanning the working directory**:

Detection rules (in priority order):

1. Any of the following **backend indicators** exists in the working directory -> classify as `backend`:
   - `requirements.txt` / `pyproject.toml` contains `fastapi` / `uvicorn` / `django` / `flask` / `gunicorn`
   - `manage.py`
   - Top-level `pom.xml` / `build.gradle` (JVM projects such as Spring Boot)
   - `go.mod`
   - `Cargo.toml` (and not a purely wasm frontend)
   - `composer.json` (PHP)
   - `Gemfile` contains `rails` / `sinatra`
   - `package.json` contains backend framework dependencies such as `express` / `fastify` / `koa` / `hapi` / `nest`
2. Only `index.html` / static HTML files exist -> classify as `static`
3. `package.json` exists without backend framework dependencies (pure frontend projects such as Vite / CRA / Next static export / Vue / Astro / Nuxt SSG) -> classify as `static`
4. Detection is inconclusive -> ask the user whether to "publish as a pure frontend" or "publish as a containerized backend," **once only** as a fallback

After classification, route as follows:

- `static` -> **static sub-pipeline** (Steps 3 -> 4 -> 5 -> 6 -> 7 -> 8)
- `backend` -> **backend sub-pipeline** (Steps 3 -> 3b -> 5 -> 7 -> 8; Step 3b replaces Steps 4/6)

### 进入 static 分支前的运行时约束告知

After classifying the project as `static`, explicitly state the following platform limitations in the conversation **before entering Step 3**:

> **运行时约束：本应用将发布到 [MonkeyCode-AI User Showcase](https://monkeycode-ai.gallery/)。在线运行时有下面两项限制：**
>
> 1. **Data can only be stored in the browser**: A pure frontend application has no server-side persistence layer. Available storage is limited to the current browser's `localStorage` / `sessionStorage` / `IndexedDB`. Data does not carry over when the user changes browsers or devices or clears the cache; data is not shared among users.
> 2. **Publicly visible**: After publication, the application is publicly visible in the User Showcase (monkeycode-ai.gallery), and anyone can access it.

Then use the `question` tool to request confirmation, with options "Continue publishing" / "Cancel."

- User selects "Continue publishing" -> enter Step 3
- User selects "Cancel" -> terminate this publication

### 进入 backend 分支前的运行时约束告知

只讲与在线运行阶段相关的部分。镜像构建阶段的细节（Dockerfile 怎么写、是否用 supervisord、依赖怎么下载）由本技能内部处理，与用户无关。

After classifying the project as `backend`, explicitly state the following platform limitations in the conversation **before entering Step 3b**:

> **运行时约束：本应用将以容器形态发布到 [MonkeyCode-AI User Showcase](https://monkeycode-ai.gallery/)。在线运行时有下面四项限制：**
> 
> 1. **Single container**: The platform schedules only one container. If the application depends on components such as a database, object storage, cache, or queue, they run in the same container as the application; independent external services are not supported.
> 2. **无外网**：容器访问不到公网或任何外部服务。远程数据库、S3、第三方 API、OAuth / 支付 / 微信、CDN、外部 LLM 均不可达。上线后应用只对外提供访问，出向网络不具备。
> 3. **No persistent storage**: The file system is reset when the service is updated, restarts unexpectedly, or operations rebuilds the container. All runtime writes (SQLite, user uploads, logs, caches, and so on) are lost.
> 4. **Publicly visible**: After publication, the application is publicly visible in the User Showcase (monkeycode-ai.gallery), and anyone can access it.

Then use the `question` tool to request confirmation, with options "Continue publishing" / "Cancel."

- User selects "Continue publishing" -> enter Step 3b
- User selects "Cancel" -> terminate this publication

---

## Step 3 - Detect Project Type

Reuse the detection logic from `deploy-website`. Route according to the automatic classification from Step 2:

### static Branch (kind=static)

| Detection Result | Route |
|---|---|
| `package.json` exists (Node project) | -> **Node build branch** (Step 4, Branch B/C) |
| Only `index.html` / static HTML files exist | -> **Static branch** (Step 4, Branch A) |

#### Package Manager Detection (Node Projects Only)

Priority order:
1. `pnpm-lock.yaml` -> `pnpm`
2. `yarn.lock` -> `yarn`
3. `package-lock.json` -> `npm`
4. None exists -> default to `npm`

#### Build Command Resolution (Node Projects Only)

In priority order:
1. `scripts.build` in `package.json` -> `<pkgMgr> run build`
2. Known default framework artifact directories: Vite/CRA/Astro -> `dist`, Next.js static export -> `out`, react-scripts -> `build`
3. README fallback: scan `README*` for commands containing `build` / `compile` / `dist` and extract them
4. If all of the above fail -> **ask the user** to specify the build command; do not guess

#### Expected Artifact Directory

Record the expected output directory (`dist` / `out` / `build`) for use in Step 4.

### backend Branch (kind=backend)

Detect the project language/framework, covering at least the following cases:

| Detection Indicator | Inferred Type |
|---|---|
| `package.json` contains `express` / `fastify` / `koa` / `hapi` | Node-Express family |
| `requirements.txt` / `pyproject.toml` contains `fastapi` / `uvicorn` | FastAPI |
| `manage.py` + `requirements.txt` contains `django` + `gunicorn` | Django + gunicorn |
| Top-level `pom.xml` / `build.gradle` with a `*.jar` artifact (Spring Boot) | Spring Boot jar |
| `go.mod` | Go |
| `Cargo.toml` | Rust |
| Other | Ask the user for the base image and startup command; do not guess |

Record the inferred result for Step 3b to use when generating the Dockerfile.

---

## Step 3b - backend Sub-pipeline

> Execute only when Step 2 automatically classifies the project as `backend` and the user selects "Continue publishing" after being informed of the four runtime limitations. After completion, skip Steps 4/6 and proceed directly to Steps 5, 7, and 8.

### 3b.0 平台限制（生成 Dockerfile 前先过一遍）

The showcase platform imposes four hard constraints on backend containers. All must be met, or the image will not run correctly.

#### A. Single Container + Process Orchestration (supervisord as Needed)

- The platform schedules **one container only** and does not support docker-compose / k8s pod / sidecar
- Choose one of two process orchestration strategies **based on auxiliary component requirements** (the Skill determines this in 3b.1):
  - **Single-process approach (default)**: the application has no auxiliary dependencies such as a DB / object storage / cache / queue and is a stateless backend process -> **start the application process directly with `ENTRYPOINT` / `CMD`**; do not introduce supervisord
  - **Multi-process approach**: the application depends on auxiliary components such as a DB / object storage / cache / queue -> package **all of these components into the same image**, and use **supervisord** to start and supervise them with the application process, ordered by `priority`
- Localize auxiliary components under the multi-process approach:
  - Relational DB (PostgreSQL / MySQL / MariaDB) -> package it entirely into the image and load the initial schema into the data directory in the builder stage
  - Object storage (MinIO / SeaweedFS) -> package it entirely into the image and initialize the bucket in the container startup script
  - Redis / Memcached / Elasticsearch / RabbitMQ and others -> likewise, start all of them locally
- 应用代码**通过 `127.0.0.1` / `localhost` / Unix socket 连辅助组件**，不用外部主机名或端点

#### B. No External Network in the Container (Offline at Runtime)

At runtime, the container is **completely cut off from the public Internet and external networks**:

- Outbound DNS, TCP, and UDP are all unreachable; remote DBs, remote S3, remote Redis, third-party APIs, OAuth IdPs, CDNs, `pip` / `npm` / `apt`, and others are **all unavailable**
- The image must be **fully self-contained**: download every resource required at runtime in advance in the **builder stage and COPY it into the runtime stage**, including but not limited to:
  - Application dependency packages (already installed in the builder; directly copy venv / node_modules / target/release / vendor into runtime)
  - Model weights, embedding files, tokenizers
  - Fonts, dictionaries, geographic libraries, localization resources
  - Initial DB schema (`*.sql`) and seed data
  - Static frontend artifacts (for a combined frontend/backend image)
  - HTTPS root certificates (if the application previously connected directly to the public Internet with CA validation, change it to trust only internal certificates or simply use internal HTTP)
- External exposure: **only one port, `service_port`**, with the platform reverse proxy providing the external HTTP service

#### C. No Persistent Storage in the Container

- Service update deployments, unexpected container crashes, and operations-side restarts all **rebuild the container** (destroy the old instance and start a new instance from the image)
- No volume / bind mount is mounted; all file-system writes are lost upon rebuild
- A DB / object store packaged inside the container **is also reset**. After a restart, the supervisord startup script must reinitialize the schema and seed data

Dockerfile 不用 `VOLUME` 声明数据目录（声明无效，还会让人误以为数据能留下）。

If the project **strongly depends** on an external persistence layer or external API (for example, it must connect to real WeChat / payment / external LLM services), inform the user again that "the relevant features may not function correctly after deployment." Continue building and publishing only after the user accepts this.

#### D. Resource Limits

- CPU: 1 core
- Memory: 1 GiB (including swap)
- Image tar.gz: <= 500 MB

When packaging auxiliary components such as a DB, object storage, or models, reduce them as much as possible to fit these limits.

### 3b.1 Generate the Dockerfile

Based on the detection result from Step 3, the AI generates a **multi-stage alpine** `Dockerfile` at `/tmp/Dockerfile`. This Dockerfile is specifically for building the container image published to showcase. **Do not** write this Dockerfile to the user's working directory.

Hard authoring constraints:

- The final (runtime) stage must be based on alpine or an alpine-flavored language image (such as `eclipse-temurin:21-alpine-jdk`)
- In principle, `apt-get` / `dnf` / `yum` are **prohibited** in the runtime stage. If packages must be installed, cleanup must be performed afterward (such as `apt clean`)
- **Prohibit** `ADD <url>`; explicitly download all external resources to disk in the builder stage using `RUN curl/wget`
- Multiple stages are required; the runtime stage may only `COPY --from=builder` compiled artifacts / runtime dependencies (including runtime resources such as model weights, fonts, initialization SQL, and root certificates) and must not run any networked command
- Automatically select the process orchestration strategy according to 3b.0 Section A: single-process approach `CMD ["application command", ...]`; multi-process approach `CMD ["/usr/bin/supervisord","-c","/etc/supervisord.conf","-n"]` (see 3b.1.a for configuration)
- `CMD` must use exec form (JSON array)
- Must `EXPOSE <service_port>`, matching the multipart field `service_port`; auxiliary component ports (DB / Redis / MinIO, and others) use only 127.0.0.1 and **must not be EXPOSEd**

#### 3b.1.a supervisord Configuration (Multi-process Approach Only)

> Use this section only when the application depends on auxiliary components (DB / object storage / cache / queue, and others). The single-process approach skips this section and writes `CMD ["application command", ...]` directly in the runtime stage.

The runtime stage must install supervisord and provide a configuration file:

```dockerfile
# In the runtime stage
RUN apk add --no-cache supervisor
COPY supervisord.conf /etc/supervisord.conf
COPY --from=builder /app /app
EXPOSE <service_port>
CMD ["/usr/bin/supervisord","-c","/etc/supervisord.conf","-n"]
```

Minimal `supervisord.conf` template (add or remove `[program:*]` sections according to the project's actual auxiliary components, and use `priority` to control startup order; lower numbers start earlier):

```ini
[supervisord]
nodaemon=true
user=root
logfile=/dev/stdout
logfile_maxbytes=0
pidfile=/run/supervisord.pid

[program:postgres]
priority=10
command=/usr/local/bin/docker-entrypoint.sh postgres
user=postgres
autostart=true
autorestart=true
stdout_logfile=/dev/stdout
stdout_logfile_maxbytes=0
stderr_logfile=/dev/stderr
stderr_logfile_maxbytes=0

[program:app]
priority=50
command=/app/start.sh
autostart=true
autorestart=true
stdout_logfile=/dev/stdout
stdout_logfile_maxbytes=0
stderr_logfile=/dev/stderr
stderr_logfile_maxbytes=0
```

Before starting the application process, `/app/start.sh` must:

1. Wait for auxiliary components to become ready (`pg_isready` / `redis-cli ping` / health probe script, for at most 30 seconds)
2. Idempotently load the initial schema and seed data (from `*.sql` baked into the image during the builder stage)
3. Then `exec` the application process (preserving PID 1 child-process semantics so supervisord can reap it)

> supervisord 配置文件 `supervisord.conf` 与启动脚本 `start.sh` 在 `/tmp/` 生成，再 `COPY` 进镜像；用户工作目录里不留这两个文件。

#### 3b.1.b Auxiliary Component Packaging Guide (Multi-process Approach Only)

| Component | Recommended Approach |
|---|---|
| PostgreSQL | Install `postgresql` and initialize with `initdb` in the builder stage; use `apk add postgresql` in the runtime stage; start `postgres -D /var/lib/postgresql/data` with supervisord; COPY the schema from the builder and load it with `psql -f` in the startup script |
| MySQL/MariaDB | Run `apk add mariadb mariadb-client` in the runtime stage; complete `mysql_install_db --user=mysql` in the builder; start `mysqld --user=mysql` with supervisord |
| Redis | Run `apk add redis` in the runtime stage; start `redis-server --bind 127.0.0.1 --save ""` with supervisord (disable persistence or write to a temporary directory in the container) |
| MinIO | Download the minio binary with `wget` in the builder stage; COPY it into runtime; start `minio server /data --address 127.0.0.1:9000` with supervisord; initialize the bucket with `mc` in the startup script |
| Heavyweight components such as Elasticsearch / Kafka | They do not fit in 1 GiB of memory. **Tell the user to replace them with a lightweight alternative** (such as SQLite FTS / Redis Streams / NATS embedded) or terminate this publication |

### 3b.2 Confirm the Container Runtime (Required)

**Prefer `docker`; fall back to `podman` only when `docker` is unavailable.**

In all subsequent steps, use `"$RUNTIME"` instead of the literal `docker`, because the docker / podman CLIs have compatible parameters for build / run / save operations (podman is rootless and may require a one-time `podman system migrate` on its first run; handle this if encountered).

### 3b.3 Local build

The build phase **must** use `--network host` so the builder stage can directly reuse the host network when fetching dependencies (apt/apk sources, and others):

```bash
TAG="showcase-publish-$(openssl rand -hex 4):tmp"
"$RUNTIME" build --network host -t "$TAG" -f /tmp/Dockerfile .
```

If the build fails, print the last part of stderr (at most 200 lines), **terminate immediately**, and **do not** continue uploading.

### 3b.4 Local run + healthcheck

Select an unused host port (detect it with a script; do not hard-code it). `$SVC` is the in-container application port (`service_port`) determined when generating the Dockerfile.

During the local healthcheck phase, **do not specify** `--network`; use the container runtime's default network (docker defaults to `bridge`, podman defaults to `slirp4netns` / `pasta`) so the host can reach the port mapping directly with `curl 127.0.0.1:$HOST`. The Skill guarantees the offline self-check through the Dockerfile authoring constraints in 3b.1; it does not depend on runtime network isolation:

```bash
"$RUNTIME" run -d --rm \
  --cpus=1 --memory=1g --memory-swap=1g \
  -p $HOST:$SVC \
  --name "${TAG%:*}-run" \
  "$TAG"
```

**Prohibit** `--privileged`, `--network host`, and `bind mounts outside the build context`.

Because the image may need to start a DB / object store before the application, **extend the total healthcheck duration to 90 seconds**, probing every 3 seconds:

```bash
for i in $(seq 1 30); do
  code=$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1:$HOST<healthcheck_path>" || echo 000)
  case "$code" in
    200|204|302|401) ok=1; break;;
  esac
  sleep 3
done
```

The AI selects the healthcheck path (such as `/`, `/healthz`, `/api/health`) and acceptable status code set based on the application type (default `{200,204,302,401}`).

On any failure (container startup failure / no acceptable status code within the 90-second healthcheck):

1. Print the last part of `"$RUNTIME" logs <container>` (<= 200 lines); also print supervisord child-process logs if available
2. Run `"$RUNTIME" stop <container>` + `"$RUNTIME" rmi $TAG` + clean up `/tmp/Dockerfile`; for the multi-process approach, also clean up `/tmp/supervisord.conf` and `/tmp/start.sh` (skip files that do not exist)
3. **Terminate immediately** and **do not** continue uploading

### 3b.5 Export the Image

After the healthcheck passes:

```bash
"$RUNTIME" stop "${TAG%:*}-run"
# The server loads through the Docker daemon, so output must use docker-archive format;
# docker save uses this format by default, while podman save must explicitly specify --format docker-archive.
if [ "$RUNTIME" = "podman" ]; then
  "$RUNTIME" save --format docker-archive "$TAG" | gzip -1 > /tmp/showcase-image.tar.gz
else
  "$RUNTIME" save "$TAG" | gzip -1 > /tmp/showcase-image.tar.gz
fi
```

**Mandatory self-check**:

```bash
size=$(stat -c%s /tmp/showcase-image.tar.gz)
test "$size" -le $((500*1024*1024)) || { echo "Image exceeds 500MB"; exit 1; }
```

If it exceeds 500MB -> terminate and tell the user to reduce the artifact (multi-stage compilation + alpine + copy only necessary files).

### 3b.6 Prepare multipart Fields

Record the fields required by Step 8:

- `kind=backend`
- `site_image=@/tmp/showcase-image.tar.gz`
- `service_port=<in-container application port>`
- `healthcheck_path=<path used in 3b.4>`

> The backend branch **does not** generate `/tmp/dist.zip` and **does not** include `site_zip_file`.

### 3b.7 Cleanup (Required After Either Success or Failure in Step 8)

```bash
"$RUNTIME" rmi "$TAG" 2>/dev/null || true
rm -f /tmp/Dockerfile
rm -f /tmp/supervisord.conf  # Does not exist under the single-process approach; rm -f has no effect
rm -f /tmp/start.sh           # Does not exist under the single-process approach; rm -f has no effect
rm -f /tmp/showcase-image.tar.gz
```

---

## Step 4 - Prepare the Static Artifact (static Branch Only)

> The backend branch skips this section and proceeds directly to Step 5.

Goal: obtain a directory that **contains `index.html` directly at its top level** (denoted `<artifact_dir>`).

Clean up the old artifact before packaging:

```bash
rm -f /tmp/dist.zip
```

### Branch A - Pure Static HTML Project
Use the project root directly as `<artifact_dir>`.

### Branch B - Node Project with an Existing dist
If the expected artifact directory exists and **contains `index.html`**, use it as `<artifact_dir>`.

### Branch C - Node Project Without dist (Build Required)

1. If `node_modules` does not exist, run `<pkgMgr> install`.
2. Run the resolved build command. On failure, output the end of stderr and **terminate**; do not retry blindly.
3. Locate `index.html`:
   - First search within the expected artifact directory
   - If not found, use this fallback: `find . -maxdepth 3 -name index.html -not -path './node_modules/*'`
   - If there are multiple candidates, choose the one with the **shortest path**
   - If still not found -> terminate and report `Build completed but index.html was not found`

---

## Step 5 - Generate and Confirm Application Metadata

**Generate automatically first, then ask the user about each item**. Make a separate `question` tool call for each field; **do not** combine multiple fields into one question.

### 5a. Automatically Generate `site_name` and `site_description` Based on Application Content

- **static branch**: synthesize from `<title>` / `<meta name="description">` / `<h1>` / above-the-fold body text in `<artifact_dir>/index.html`; for Node projects, the root `package.json` `name` and `description` may also be referenced
- **backend branch**: synthesize from name + description in the project root's `package.json` / `pyproject.toml` / `pom.xml` / `Cargo.toml` / `go.mod`; if a README exists, extract the introductory first paragraph

Output:
- Automatically generated `site_name` (a one-line short title, <= 30 characters)
- Automatically generated `site_description` (a one-line summary, <= 80 characters)

> If there is no parsable content, **do not provide a default "Satisfied" option** in the subsequent question; require the user to enter a value.

### 5b. Ask for the Application Name (`question` Tool, One Separate Call)

```
question: The automatically detected application name is "<generated site_name>". Use it?
header: Application Name
options:
  - Satisfied, use this
```

- User selects **Satisfied, use this** -> use the automatically generated value
- User enters a value through **Other** -> use that input

### 5c. Ask for the Application Description (`question` Tool, One Separate Call)

```
question: The automatically detected application description is "<generated site_description>". Use it?
header: Application Description
options:
  - Satisfied, use this
```

- Handle it using the same logic as 5b.

### 5d. Ask for the Application Author (`question` Tool, One Separate Call)

```
question: Enter the application author's ID (select an option below or enter one manually)
header: Application Author
options:
  - Anonymous author
```

- User selects **Anonymous author** -> `site_author = "anonymous"`
- User enters a value through **Other** -> use that input

---

## Step 6 - Package (static Branch Only)

> The backend branch skips this section; its artifact was prepared in 3b.4.

You must `cd` into `<artifact_dir>` before packaging to ensure the zip has no wrapper directory; also **exclude development-related files**:

```bash
cd <artifact_dir> && zip -r /tmp/dist.zip . \
  -x ".git/*" \
  -x ".git" \
  -x "node_modules/*" \
  -x "node_modules" \
  -x "src/*" \
  -x ".env*" \
  -x "*.log" \
  -x ".DS_Store" \
  -x ".vscode/*" \
  -x ".idea/*" \
  -x "package.json" \
  -x "package-lock.json" \
  -x "pnpm-lock.yaml" \
  -x "yarn.lock" \
  -x "tsconfig*.json" \
  -x "*.ts" \
  -x "*.tsx" \
  -x "vite.config.*" \
  -x "webpack.config.*" \
  -x "next.config.*"
```

> **Notes**:
> - For **Branches B/C** (the artifact directory is under `dist`/`out`/`build`), the directory already contains built static assets, so most exclusions will not match; retain the exclusion rules as a defensive fallback
> - For **Branch A** (the artifact directory is the project root), the exclusions above effectively prevent source code, dependencies, version-control directories, and configuration files from being packaged
> - If `<artifact_dir>` genuinely contains required `.ts`/`.tsx` assets (very rare), adjust the exclusions; otherwise retain the defaults above

**Mandatory self-check**:

```bash
unzip -l /tmp/dist.zip | head -30
```

Requirements:
- `index.html` is at the **top level** (without any path prefix)
- Development files such as `.git/`, `node_modules/`, `src/`, and `package.json` **must not** appear in the output

If any requirement is not met, terminate immediately; **do not** upload a noncompliant package.

---

## Step 7 - Determine the `ticket` (the **Key**)

Determine whether the current session already has a cached key (ticket):

- **A cached key exists** (an application was previously submitted successfully in this session) -> reuse it directly, **skip 7a**, and enter Step 8
- **No cached key exists** (the first submission in this session) -> enter 7a and ask the user

### 7a. Ask Whether to Reuse an Existing Application (Run Once on the First Submission)

Use the `question` tool and **provide only one explicit option**. The remaining Other input itself represents "Yes, enter the key to update an existing application"; its placeholder must use that wording:

```
question: Was this application submitted in another task before? Do you need to update an existing application or submit a new one? To update it, select [Other] and enter the key provided by the previous task.
header: Update an Existing Application?
options:
  - No, submit a new application
  # Other: The input placeholder/meaning is "Yes, enter the key to update an existing application"; the user enters the key here directly
```

- User selects **No, submit a new application** -> leave the key empty (do not include the `ticket` field)
- User enters a key in the **Other** input -> use the entered string as `ticket`
- If the user's input is an empty string or whitespace only -> treat it as not provided and handle it as "submit a new application"

> **Cross-kind notice**: if the user provides a ticket and the current kind differs from the original application's kind as they remember it (this cannot be determined automatically on the client side; rely on the user's statement), before submission state, "This will switch the original application from X to Y and return it to pending review," and obtain confirmation. The server replaces the original application in full during the switch.

---

## Step 8 - Publish

Submit all fields and the artifact to the showcase API in one multipart form POST.

### 8a. Call the API

**static branch** (choose either without ticket / with ticket):

```bash
curl -f -X POST \
  -F "client_id=<client_id>" \
  -F "kind=static" \
  -F "site_name=<application name>" \
  -F "site_author=<application author>" \
  -F "site_description=<application description>" \
  [ -F "ticket=<ticket>" ] \
  -F "site_zip_file=@/tmp/dist.zip" \
  https://ugc-submit.monkeycode-ai.gallery/v1/create
```

**backend branch**:

```bash
curl -f -X POST \
  -F "client_id=<client_id>" \
  -F "kind=backend" \
  -F "site_name=<application name>" \
  -F "site_author=<application author>" \
  -F "site_description=<application description>" \
  [ -F "ticket=<ticket>" ] \
  -F "site_image=@/tmp/showcase-image.tar.gz" \
  -F "service_port=<in-container application port>" \
  -F "healthcheck_path=<healthcheck path>" \
  https://ugc-submit.monkeycode-ai.gallery/v1/create
```

Field descriptions:

| Field | static | backend | Source |
|---|---|---|---|
| `client_id` | Required | Required | Output of the `hostname` command in Step 1 |
| `kind` | Required (`static`) | Required (`backend`) | Automatic classification result from Step 2 |
| `site_name` | Required | Required | Step 5b |
| `site_author` | Required | Required | Step 5d |
| `site_description` | Required | Required | Step 5c |
| `site_zip_file` | Required | Must not appear | Step 6 |
| `site_image` | Must not appear | Required | Step 3b.4 |
| `service_port` | Must not appear | Required | Step 3b |
| `healthcheck_path` | Must not appear | Optional (default `/`) | Step 3b.3 |
| `ticket` | Optional | Optional | Step 7 |

Key points:

- `-f` makes non-2xx HTTP statuses return a nonzero exit code
- On failure, **retry at most once** (to handle network fluctuations)
- All fields must be shell-escaped
- **Do not** additionally pass fields such as `user_id` / `task_id`
- **Do not** mix a kind with artifact fields for another kind (for example, `kind=static` together with `site_image`)

### 8b. Parse the Response

Server response structure:

```json
{
  "status": 200,
  "data": {
    "message": "success or error detail",
    "site_url": "https://xxxxx.monkeycode-ai.gallery",
    "ticket": "<reuse this ticket within the session>"
  }
}
```

Handling rules:
- If `status` is 2xx and `data.site_url` is nonempty -> treat as success and extract `site_url`
- **If `data.ticket` is nonempty**: **cache it in the current session context**. Automatically use this `ticket` for every subsequent submission in this session, and do not ask the user again
- **If `data.ticket` differs from the `ticket` included in the request**: the final response must **explicitly tell the user the new `ticket` value**
- Otherwise -> treat as failure, report `data.message` to the user as the error reason, and **do not** pretend it succeeded

### 8c. Provide User Feedback

成功时（`site_url` 单独成行、渲染为可点击链接，不放代码块；不引导用户去做微信/公众号绑定）：

```
The application has been submitted for publication. Preview URL:

<site_url>

The application requires administrator review before going online. To learn its review status, ask here and I will check and tell you.
```

**If the `data.ticket` returned by the server differs from the `ticket` included in the request**:

```
The application has been submitted for publication. Preview URL:

<site_url>

The update credential ticket for this application is: `<new_ticket>`
To update this application again later, provide this ticket to me in a new session.

The application requires administrator review before going online. To learn its review status, ask here and I will check and tell you.
```

On failure, report the HTTP status code and `data.message`; **do not** fabricate an application URL.

---

## Query Review Status (Execute When Explicitly Asked by the User)

When the user asks in this session about review / going online / rejection reasons / takedown reasons, call:

```
GET https://ugc-submit.monkeycode-ai.gallery/v1/status?client_id=<client_id>&ticket=<ticket>
```

- `client_id`: the value obtained from `hostname` in Step 1; it **must** match the value used for submission
- `ticket`: the `ticket` cached within the session

The server uses `ticket` to locate the site, then verifies that `client_id` matches the site. If either does not match, it returns 404 `site_not_found`.

### Response Fields

On success, it returns `{ code: 0, data: {...} }`; fields in `data`:

| Field | Type | Description |
|---|---|---|
| `slug` | string | Application slug |
| `status` | string | `pending_review` / `online` / `offline` / `rejected` |
| `kind` | string | `static` / `backend` |
| `block_resubmit` | bool | When `true`, the same `client_id` is prohibited from submitting again; another call to `/v1/create` returns 403 `resubmit_blocked` |
| `takedown_reason` | string (optional) | Reason entered by the administrator when rejecting / taking down the application; generally present when `status` is `rejected` or `offline` |
| `last_deployed_at` | int64 (optional) | Millisecond timestamp of the last deployment |

### User-facing Response Wording

Use four categories according to `status`:

- `pending_review` -> "The application has been submitted and is under review."
- `online` -> "The review passed and the application is online. URL: `<site_url>`"
- `rejected` -> "The application did not pass review." + if `takedown_reason` exists, append "Reason: `<takedown_reason>`." If `block_resubmit=true`, tell the user, "The administrator has prohibited the current client_id from submitting this application again"
- `offline` -> "The application has been taken offline." + if `takedown_reason` exists, append "Reason: `<takedown_reason>`"

**Prohibited**:
- Do not proactively poll this endpoint; call it only when the user asks
- Do not guess the reason; when `takedown_reason` is empty, say only "The administrator did not provide a reason"
- Do not expose raw JSON other than `slug` in the response

---

## Recall the Application (Execute Only When Explicitly Requested by the User)

> **This section is a fallback channel for the user and is not part of the publishing process. After publication, do not proactively tell the user that "the application can be recalled"**. Enter this section only when the user explicitly expresses an intent such as "take it offline / recall it / delete the application I just published."

A recall does not mean the Skill automatically removes the application; it forwards the request to an administrator. The application does not go offline immediately after submission. After receiving the request, an administrator manually decides whether to take it offline / reject / retain it.

### Call the Endpoint

```bash
curl -f -X POST \
  -F "client_id=<client_id>" \
  -F "ticket=<ticket>" \
  [ -F "reason=<recall reason>" ] \
  https://ugc-submit.monkeycode-ai.gallery/v1/recall
```

Field descriptions:

| Field | Required | Source |
|---|---|---|
| `client_id` | Required | Output of the `hostname` command in Step 1; must match the value used for publication |
| `ticket` | Required | `ticket` cached within the session; if the user does not have a ticket, ask them to provide it in a new session or retrieve it from the original session |
| `reason` | Optional | The recall reason stated by the user, forwarded verbatim to the administrator; truncate beyond 500 characters |

### Response Handling

Server response structure:

```json
{
  "slug": "...",
  "status": "pending_review | online",
  "recall_requested_at": 1719300000000,
  "already_requested": false
}
```

- `already_requested=false` -> the recall was successfully marked for the first time; tell the user, "The administrator has been notified; awaiting manual processing"
- `already_requested=true` -> the same recall request was submitted previously; tell the user, "A recall request was submitted previously and is still awaiting administrator processing. Please wait patiently"
- HTTP 4xx:
  - `site_not_found` -> ticket / client_id does not match; tell the user, "The corresponding application could not be found. Please confirm that the ticket is correct"
  - `invalid_request` with `detail.status` equal to `offline` / `rejected` -> the application is already offline / did not pass review, so no recall is needed; simply tell the user its current status
- Network failure / 5xx -> retry once; if it still fails, report the failure accurately

### User-facing Response Wording (First Success)

```
A recall request has been submitted to the administrator and is awaiting manual processing.

The application is currently still in the <status> state and will only go offline after the administrator processes it. To learn the result, ask here and I will check and tell you.
```

### 召回通道的边界

- 发布流程中不主动提「可以召回」。召回是兜底通道，主动提会让人随手召回。
- 召回结果如实报。服务端没有返回 2xx 就照原样报出状态码。
- 无 `ticket` 不盲调。先确认会话里缓存了 ticket，或由用户明确提供。
- 召回是人工处理，`/v1/recall` 调用成功即结束本流程，不轮询 `/v1/status` 等结果。

---

## 固定序列

### 通用

- **触发读最新一条消息**：同会话发布过一次后，用户接着改代码/内容但不指名 `publish-website` 时，走 `/deploy-website` 预览中间版本，不重跑发布流程，也不主动问「要不要再发布一次」
- **Step 1b 先跑**：命中「软件分发包（apk/ipa/exe/dmg/msi/pkg 等安装包）」或「未二次开发的开源 CMS / 面板（WordPress / Halo / Typecho / aaPanel / 1Panel / cPanel 等）」时，切到 `deploy-website`，本流水线收束
- **`client_id` 取自 `hostname` 的实际输出**，不用其他值替代
- **`ticket` 只在本会话首次提交时问一次**；首次成功后缓存进会话上下文，后续提交自动复用
- **`ticket` 来源**：用户输入或服务端返回，二者之一
- **应用名/描述按实际内容生成**，不编造；用户给出的输入优先级最高
- **三个元数据字段分三次 `question` 调用**，一次问一个
- **请求体不带 `user_id` / `task_id`**
- **失败按原样报出**：哪一步失败报哪一步，不写成成功
- **上传完成即结束**，不轮询审核状态
- **最终回复里不提微信/公众号绑定**
- **最终回复里 `site_url` 用行内代码或裸链接，不放代码块**
- **服务端返回的 `data.ticket` 与请求里的 `ticket` 不同时**，在最终回复里明确告知新值
- **成功判定看 `status` 与 `data.site_url` 两项**
- **跨 kind 切换不算错误**，说明「原应用将从 X 切成 Y，重新进入待审核」

### 仅 static 分支

- **打包前先 `rm -f /tmp/dist.zip`**
- **zip 根目录含 `index.html`**，不含 `.git`、`node_modules`、`src`、`package.json` 等开发文件；用 `unzip -l` 核对

### 仅 backend 分支（Dockerfile + 容器化）

- **单容器 + 按需 supervisord**：平台只调度一个容器
  - 项目用到的辅助组件（DB / 对象存储 / Redis / 队列等）打包进同一个镜像
  - 按检测结果二选一：
    - 无辅助组件依赖（单进程后端）→ 直接 `CMD ["应用命令", ...]`，不引入 supervisord
    - 有辅助组件依赖 → 运行时阶段装 supervisord，用 `supervisord -n` 拉起并托管每个进程，`CMD ["/usr/bin/supervisord","-c","/etc/supervisord.conf","-n"]`
  - 多进程方案下，supervisord 配置与启动脚本在 `/tmp/` 生成，再 COPY 进镜像；用户工作目录里不留这些文件
  - 应用通过 `127.0.0.1` / `localhost` / Unix socket 连辅助组件；除 `service_port` 外不 `EXPOSE` 其他端口
- **容器运行时无外网**：出向 DNS / TCP / UDP 均不可达
  - 运行时阶段不含联网命令（`curl` / `wget` / `pip install` / `npm install` / `apk fetch` 等）
  - 模型权重、字体、词典、初始化 SQL、根证书、前端静态产物等运行时资源，全部在 builder 阶段下载完并 COPY 进运行时阶段
  - 应用代码去掉运行期外部调用（远程模型、远程配置、第三方 API、用量上报等）
  - 本地 `"$RUNTIME" build` 带 `--network host`，让 builder 阶段经宿主网络取依赖
  - 本地健康检查阶段 `"$RUNTIME" run` 不指定 `--network`（用容器运行时默认网络）。离线自检由 3b.1 的 Dockerfile 约束在源头保证（运行时阶段无联网命令、资源在 builder 下载），不依赖运行期网络隔离
  - 进入 backend 分支前，Step 2 已用单独的 `question` 说明「无外网」「单容器」「无持久化」「1C1G」四项并取得「继续发布」
- **容器无持久化**：服务更新、异常崩溃、运维重建都会重建容器，文件系统写入全部丢失
  - Dockerfile 不用 `VOLUME` 声明数据目录
  - 打进容器的 DB / 对象存储重启后归零；supervisord 启动脚本幂等地重放初始 schema 与种子数据
  - 应用不假设上一次启动写的文件在下次启动还在
  - 用户上传 / 运行期产物按「重启即丢」处理，或存进容器内自带的 DB 实例
- 最终（运行时）阶段基于 **alpine**（或用 alpine 变体的语言镜像，如 `eclipse-temurin:21-alpine-jdk`）
- 运行时阶段不装包：不用 `apt-get` / `dnf` / `yum`
- 不用 `ADD <url>`
- **多阶段构建**；运行时阶段只 COPY 产物，不做编译
- **Dockerfile / supervisord.conf / start.sh 写在 `/tmp/`**，不落到用户工作目录（supervisord.conf / start.sh 仅多进程方案生成）
- **优先 `docker`；没有就用包管理器装 `podman` 继续**。不手工装 docker engine；构建 / 运行 / 导出统一引用 `"$RUNTIME"`
- 本地 `"$RUNTIME" run`（健康检查阶段）不传 `--privileged`、`--network host`、`--network none`，不挂载构建上下文之外的目录
- **构建 / 运行 / 健康检查任一失败 → 打印 stderr 尾部并停止上传**
- 镜像 tar.gz ≤ 500MB
- 清理跑 `"$RUNTIME" rmi <tag>` 与 `rm -f /tmp/Dockerfile /tmp/supervisord.conf /tmp/start.sh /tmp/showcase-image.tar.gz`（成功与失败都跑；单进程方案下 supervisord.conf / start.sh 不存在，`-f` 静默跳过）

---

## Error Handling Quick Reference

| Failure Point | Action |
|---|---|
| `hostname` command fails | Report the error and terminate |
| Step 1b matches a prohibited type (software distribution / direct publication of an open-source CMS or website panel) | Tell the user, "The showcase does not accept this type of site," terminate immediately, and do not enter kind classification |
| Project root cannot be found | Ask the user for the path; do not guess |
| Automatic classification is inconclusive (neither a pure frontend nor a backend project) | Ask the user for the kind according to the Step 2 fallback rule; terminate if it still cannot be determined |
| Build command cannot be resolved | Ask the user to specify the command |
| `install` fails | Output the end of stderr and terminate |
| `build` fails (frontend / `"$RUNTIME" build`) | Output the end of stderr and terminate |
| Neither `docker` nor `podman` exists, and the package manager is unavailable | Report "No available container runtime" and terminate |
| `index.html` cannot be found after the build | Output the directory structure and terminate |
| Application content has no usable metadata | Leave automatic generation empty and have the user enter it through Other in the `question` tool |
| zip self-check finds included development files | Adjust the exclusions and repackage; terminate if they still exist |
| Image tar.gz > 500MB | Tell the user to reduce the artifact (multi-stage compilation + alpine + copy only necessary files) and terminate |
| `"$RUNTIME" run` fails to start | Print the end of `"$RUNTIME" logs` (including supervisord child-process logs under the multi-process approach), clean up the container/image/`/tmp` temporary files, and terminate |
| No acceptable status code within the 90-second healthcheck | Print the end of `"$RUNTIME" logs` (including supervisord child-process logs under the multi-process approach), clean up, and terminate |
| The project requires heavyweight auxiliary components (Elasticsearch / Kafka, and others) exceeding 1C1G | Tell the user to replace them with lightweight alternatives or decompose the requirement, and terminate this publication |
| API request is not 2xx | Retry once; if it still fails, report `status` and `data.message`, then terminate |
| `data.site_url` is empty | Treat as failure, report `data.message`, and terminate |
| The `ticket` entered by the user is invalid (API returns an error) | Report `data.message` and terminate; do not automatically switch to creating a new application |
| `data.ticket` is missing (legacy server) | Still treat as success, but subsequent submissions in this session cannot use the update flow |
| API returns `kind_mismatch` | State, "The upload fields do not match the selected type. This publication has been canceled," and terminate |
| API returns `image_too_large` | State, "The image exceeds 500MB. Please reduce the artifact (multi-stage compilation + alpine + copy only necessary files)," and terminate |
| API returns `image_invalid` | State, "Image tar validation failed. Confirm that the `"$RUNTIME" save` process was not interrupted; when using podman, explicitly specify `--format docker-archive`," and terminate |
| API returns `container_start_failed` | Pass through `data.detail` (<= 200 characters) and terminate |
| API returns `healthcheck_failed` | State, "The healthcheck failed after server startup: <detail>. Locally rerun `"$RUNTIME" run` + curl to investigate," and terminate |
