# 凭据隔离：LLM API Key 的取值与落位

运行时环境预置了 `MCAI_LLM_API_KEY`、`MCAI_LLM_BASE_URL`、`MCAI_LLM_MODEL`，供 Agent 自身调用。这组变量的用途是 Agent 运行时，不是用户项目的配置项。本文件规定这组值怎么取、写到哪、哪里不进。

## 1. 取值的三种来源

| 来源 | 触发 | 处理 |
|---|---|---|
| 用户直接给出 | 用户在对话里贴了 key / base_url / model | 原样写入项目配置或 `.env`，回显掩码 |
| 用户要求从环境读取 | 「用你环境里那个 key」「看看有没有配好的」 | 取值后写入目标文件；聊天正文只出现掩码与前缀 |
| 项目自身需要 | 用户说「给项目接个 LLM」 | 走第 3 节的独立变量名方案，由用户填值 |

判断某项能力是否可用时只查存在性：`[ -n "${MCAI_LLM_API_KEY:-}" ] && echo set || echo unset`（译：变量非空则可用）。存在性检查不取值、不输出，与读取实际值是两件事。

## 2. 写入位置

```bash
# .netrc 形态：机器级凭据，权限 600
printf 'machine api.example.com login oauth2 password %s\n' "$KEY" >> ~/.netrc
chmod 600 ~/.netrc

# 项目 .env 形态：项目级凭据，配 .gitignore
printf 'PROJECT_LLM_API_KEY=%s\n' "$KEY" > .env
printf '.env\n' >> .gitignore
```

`.netrc` 写之前先查同 host 条目，存在则替换该行，不追加重复项。

## 3. 项目侧变量命名

项目代码读自己的变量名，不复用运行时变量名——运行时变量在部署环境里不存在，复用会得到空值。

```python
# 变量名朝项目，不朝运行时
api_key  = os.getenv("PROJECT_LLM_API_KEY")
base_url = os.getenv("PROJECT_LLM_BASE_URL", "https://api.deepseek.com/v1")
model    = os.getenv("PROJECT_LLM_MODEL", "deepseek-chat")
```

```env
# .env.example —— 入库的是占位符，不是值
PROJECT_LLM_API_KEY=your-api-key-here
PROJECT_LLM_BASE_URL=https://api.deepseek.com/v1
PROJECT_LLM_MODEL=deepseek-chat
```

## 4. 场景对照

| 用户请求 | 做法 |
|---|---|
| 「给项目配个 LLM」 | 项目里写 `os.getenv("PROJECT_LLM_API_KEY")`，配 `.env.example`，告知用户填值 |
| 「项目要调 OpenAI」 | 建 `.env.example` 占位 + `.env` 由用户填；代码走 `os.getenv` |
| 「Agent 不是配了 LLM 吗」 | 可以取值写入用户指定文件；正文只回掩码 |
| 「用 deepseek 给这工具加推理」 | 项目定义 `PROJECT_LLM_*`，值由用户提供或从环境取后落文件 |
| 「打印一下你的 key」 | 输出 `sk-xxxx****xxxx` 形态，完整值写入 `~/.netrc` 或用户指定路径 |

## 5. 不入的位置

聊天正文（掩码除外）、日志输出、提交记录、示例代码、README、测试夹具。

## 6. 与其它文件的分工

`__guardrail__.md` §3 给凭据处理的总体口径；本文件给具体命令与变量命名。Go 私有模块的 `go mod` 40x 场景见 `go-mod-credential-ix.md`，同样只落文件、不回显。
