# Code Quality Standards Rule

During the development process, the following code quality standards must be adhered to. These standards ensure the functionality, maintainability, and long-term health of the code.

## 1. Functionality and Correctness (The "Does it Work?")

This is the most fundamental requirement. The code must perform the functions it claims to perform.

- **Meets Requirements**: Does the code fully and correctly implement the described requirements?
- **Correct Logic**: Is the core logic of the code correct? Are there any obvious bugs?
- **Edge Cases**: Have various edge cases been considered? For example:
  - Null, zero, negative, or extremely large input values
  - Empty lists or lists with only one element
  - Concurrent access
- **Regression Analysis**: Has existing functionality been inadvertently broken?

## 2. Design and Architecture (The "Is it Well-Designed?")

This is a higher-level consideration, concerning the "skeleton" and long-term health of the code.

- **Single Responsibility**: Does each function, class, or module do one thing and do it well?
- **Appropriate Abstraction**: Are the levels of abstraction appropriate? Is there over-engineering or under-engineering?
- **Duplicate Code (DRY)**: Is there unnecessary duplicate code? (Don't Repeat Yourself)
- **Coupling**: Is the new code overly coupled with other parts of the system? Will modifying it cause a "ripple effect"?
- **Extensibility**: If requirements change in the future, will this code be easy to extend?
- **Pattern Application**: Are appropriate design patterns correctly applied?

## 3. Readability and Maintainability (The "Can Others Understand it?")

Code is written for humans to read, and incidentally for machines to execute.

- **Clear Naming**: Are the names of variables, functions, and classes clear, accurate, and meaningful? (Avoid vague names like `data`, `temp`, `a`, `b`)
- **Simplicity**: Can the same functionality be implemented in a simpler, more straightforward way?
- **Comments**:
  - Are necessary comments present to explain "why" something is done? (The code itself should explain "what" it does)
  - Are there redundant, misleading, or outdated comments?
- **Code Smells**: Are there bad signals like overly long functions, excessive nesting, or huge classes?

## 4. Testing and Robustness (The "Is it Proven & Safe?")

Code must not only work but also be demonstrably reliable.

- **Test Quality**: If test cases are written, are they effective? Do they test the correct logic, or are they just to "make it run"?
- **Error Handling**: Are potential errors (e.g., API call failures, file read failures, database exceptions) properly handled? Will users see friendly prompts, or will the program crash?

## 5. Standards and Consistency (The "Does it Fit In?")

A project should look like it was written by one person, not a group.

- **Code Style**: Does it follow the team's coding standards (Style Guide / Linter)? (e.g., indentation, spaces, bracket placement)
- **Project Conventions**: Does it follow existing project conventions and patterns? (e.g., API response formats, logging methods)
- **Dead Code**: Has debugging `console.log` statements and commented-out code blocks (Dead Code) been removed?

## 6. Performance and Security (The "Is it Efficient & Secure?")

- **Performance**: Are there obvious performance bottlenecks? (e.g., database queries inside loops, unnecessary full table scans, memory leaks)
- **Security**: Have common security vulnerabilities been introduced? (e.g., SQL injection, Cross-Site Scripting (XSS), hard-coded keys, insufficient permission checks)

## Implementation Requirements

When generating code, the model must perform a self-check against the above six dimensions to ensure code quality meets standards before submission.