# 长时进程管理

判据是"命令会不会在超时前退出"，不是"命令用了哪个工具"。会阻塞会话的命令走后台终端，几秒内退出的走前台。

## 1. 前台

退出时间有界、输出量小的命令直接前台跑：

```bash
npm install            # 通常 10-60s
npm run build          # 有界
git clone --depth 1
curl --max-time 10 <url>
ping -c 4 <host>
timeout 30 ./script.sh
```

给网络操作加上界，避免 DNS 或 TCP 握手挂住整个会话：

```bash
curl -sS --connect-timeout 5 --max-time 20 <url>
```

## 2. 后台终端

常驻进程、持续输出、启动后要留着访问的服务，走后台终端：

```bash
# 创建（返回 terminal ID 与 PID）
background_terminal_create: npm run dev

# 取日志路径
background_terminal_output_path: <terminal-id>

# 列全部
background_terminal_list

# 停止（按终端 ID）
background_terminal_kill: <terminal-id>
```

后台终端比 `&` 与 `timeout` 好在三处：不占当前会话、日志落到可读文件、能按 ID 精确停。

典型场景：`npm run dev` / `yarn start` / `python -m http.server` / `gunicorn -b 0.0.0.0:8000 app:app` / `go run .` / `mvn spring-boot:run` / `cargo run` / 需要持续输出日志的构建。

完整用法见 `.ai-ready/skills/deploy-website/SKILL.md`：起服 → 读日志确认 → 取预览地址 → 用完清理。

耗时但一次性返回结果的操作（批量编译、全量测试、大目录打包、镜像构建）不改写成前台等待，而是交给子 agent 或后台任务：

- 子 agent：适合需要多轮判断的长链路，主会话只等结论
- 后台任务：适合单条命令跑很久，`run_in_background` 拿 task_id，结束后取输出

确实必须前台执行长命令时，先说明预计耗时与原因，用户确认后再跑。

## 3. 停止

按终端 ID 停：

```bash
background_terminal_kill: <terminal-id>
```

按进程名停（`pkill node`、`killall python`）会连带命中用户手动起的同名进程和其他项目的开发服务器，端口被占、构建中断都从这里来。确实需要按名停时，先 `pgrep -a node` 出清单，确认 PID 后再 `kill <PID>`。

## 4. 无限运行的形态

| 形态 | 为什么挂住 | 替代 |
|---|---|---|
| `watch <cmd>` | 永不退出 | 循环 + 日志文件，或 `timeout 30 watch -n 5` |
| `tail -f app.log` | 永不退出 | `tail -n 200 app.log`，之后按需再读 |
| `top` / `htop` | 交互界面，无 TTY 时卡住 | `top -bn1 \| head -20` 或 `ps aux --sort=-%cpu \| head` |
| `ping <host>` | 默认无限 | `ping -c 4 <host>` |
| `while true; do ...; done` | 永不退出 | 加计数上限或 `timeout` |
| 大表迁移 | 时长不可测 | `run_in_background` + 分批 + 进度写文件 |
| 无上限的 `find /` / `grep -r /` | 扫全盘 | 限定路径与深度：`find /var/log -maxdepth 2` |
| 大文件下载 | 速率不可控 | `curl -C - -o f <url>` + `run_in_background`，支持断点续跑 |

## 5. 长时间任务的续跑

超过单次会话长度的任务（全量构建、大批量扫描、模型训练）写成可续跑形态：

```bash
# 进度落文件，中断后从断点继续
while read -r item; do
  grep -qxF "$item" done.txt && continue
  process "$item" && echo "$item" >> done.txt
done < items.txt
```

## 6. 超时参数

`run_in_background` 之外的命令给显式上界：

```bash
timeout 120 ./long-but-bounded.sh
timeout -s KILL 30 nc -w 5 host 22
```

工具自带上界的参数优先用：`curl --max-time`、`ping -c`、`nc -w`、`Read limit`。

## 7. 交叉引用

`deploy-website/SKILL.md` 给后台终端的完整起停流程；`system-admin-commands.md` 给 `systemctl` 类常驻服务的分档。
