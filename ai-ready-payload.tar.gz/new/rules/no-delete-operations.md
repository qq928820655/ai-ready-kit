# 删除类操作的执行序列

删除是不可逆动作里回报最高的一类：一次误匹配就把用户的目录清空。本文件规定删除前的固定动作顺序，以及判断影响面要看哪几列。清单本身是"影响面"，不是"黑名单"——每一项都可以执行，前提是快照在位。

## 1. 固定序列

```
1. 快照       cp -a <target> <target>.bak.$(date +%Y%m%d%H%M%S)
2. 列清单     ls -la / find <target> -maxdepth N | tee /tmp/rm-list.txt
3. 核对       wc -l /tmp/rm-list.txt 与预期条数对齐
4. 执行       按清单逐条删，不用通配符
5. 校验       目标路径 inode 释放、空间回收、依赖进程未崩
```

第 3 步是分界点：条数对不上就回到第 2 步，不进第 4 步。

```bash
# 一份可直接用的形态
TARGET="$1"; STAMP=$(date +%Y%m%d%H%M%S)
cp -a "$TARGET" "$TARGET.bak.$STAMP"
find "$TARGET" -mindepth 1 -maxdepth 1 -print | tee /tmp/rm-list.txt
wc -l /tmp/rm-list.txt
while IFS= read -r p; do rm -rf -- "$p"; done < /tmp/rm-list.txt
```

## 2. 影响面清单

### 文件与目录
`rm`、`rm -r`、`rm -rf`、`rmdir`、`unlink`、`shred`
——快照代价：目标体积。大目录用 `rsync --link-dest` 做硬链接快照，秒级完成。

### 数据库
`DROP TABLE`、`DROP DATABASE`、不带 `WHERE` 的 `DELETE FROM`、`TRUNCATE TABLE`
——快照代价：`mysqldump` / `pg_dump` 单表。带 `WHERE` 的 DELETE 先 `SELECT COUNT(*)` 同条件。

### Git
`git rm`、`git clean -f`、`git branch -D`、`git push origin --delete`
——快照代价：零（commit 可回溯）。`git clean -f` 例外，未跟踪文件没有历史，先 `git clean -n` 出清单。

### 容器与镜像
`docker rm`、`docker rmi`、`docker system prune`、`docker volume rm`
——volume 里的数据没有第二份，`docker volume rm` 前先 `docker run --rm -v <vol>:/d alpine tar czf - /d > vol.tgz`。

### 包
`npm uninstall`、`yarn remove`、`pip uninstall`
——快照代价：`package.json` / `requirements.txt` 已在版本控制里时为零。

### 其它
带 `--delete` 的同步命令（`rsync --delete`、`aws s3 sync --delete`）、`find ... -delete`
——这类删除由源端状态驱动，源端少一个文件就等于目标端删一个。先 `--dry-run` 出清单。

## 3. 三个高危形态

| 形态 | 为什么危险 | 替代写法 |
|---|---|---|
| `rm -rf $VAR/`（变量为空） | 展开成 `rm -rf /` | `rm -rf -- "${VAR:?}"` |
| `rm -rf *`（不匹配隐藏文件，也匹配不到预期外的软链） | 结果与直觉不符 | `find . -mindepth 1 -maxdepth 1 -print0 \| xargs -0 rm -rf` |
| 删除正在被进程占用的路径 | 空间不释放，进程写已删除的 inode | 先 `lsof +D <path>` 或 `fuser -v <path>` |

## 4. 例外路径

任务本身要求清空某目录（构建产物、临时目录、测试夹具重建）时，序列简化为第 1 步 + 第 4 步：目录可重建就跳过快照，但要在回复里写明"该目录可重建，未做快照"。

`node_modules`、`dist`、`.cache`、`__pycache__`、`target/` 属于可重建目录，直接删，不必快照。

不可重建的数据（数据库表、容器卷、用户上传目录、含未提交改动的仓库）没有"可重建"这条捷径：列出受影响对象与回滚代价后，建议用户自己执行；用户要求由我做时，先快照再执行，两步都在回复里写出来。

## 5. 交叉引用

`system-admin-commands.md` 给系统级命令的分档；`__guardrail__.md` §4 给常驻服务与面板的处理口径。两者对同一批命令的口径与本文一致：可执行，附前置动作。
