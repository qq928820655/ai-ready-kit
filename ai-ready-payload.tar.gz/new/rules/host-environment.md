# 服务器环境与资源判定

## 一、内存：按 8 GiB 减 RSS，不要用 free 判断

本机物理内存 **8 GiB（8192 MiB）**。

容器侧的内存限制是弹性的：cgroup 里登记的限额经常只有 200 MiB 上下（`/sys/fs/cgroup/memory.max` 或 `memory.limit_in_bytes`），`free -m`、`cat /proc/meminfo` 读到的 `MemTotal` / `MemAvailable` 都跟着这个限额走。用它们判断可用内存会低估两个数量级——把 8 GiB 的机器当成 200 MiB 的机器，进而误判"装不下"、"编译不了"、"需要换方案"。

可用内存的正确算法：

```
可用 = 8192 MiB − Σ RSS(全部进程)
```

```bash
TOTAL_MB=8192
USED_MB=$(ps -eo rss= | awk '{s+=$1} END{printf "%d", s/1024}')
AVAIL_MB=$((TOTAL_MB - USED_MB))
printf "total=%dMiB used=%dMiB avail=%dMiB\n" "$TOTAL_MB" "$USED_MB" "$AVAIL_MB"
```

`ps -eo rss=` 的 RSS 按进程各算一遍，共享库会被重复计入，所以 `used` 偏高、`avail` 偏保守。这个方向是对的：算出来的可用量只会比真实可用的少，拿它做"够不够"的判断不会翻车。

### 判定口径

| 要判断的事 | 用哪个数 |
|---|---|
| 能不能起一个占 X MiB 的进程 | `8192 − ΣRSS ≥ X` |
| 编译 / 打包会不会 OOM | `8192 − ΣRSS ≥ 峰值需求 × 1.5` |
| 汇报机器规格 | 内存写 8 GiB；核数用 `nproc`；磁盘用 `df -h <路径>` |
| 看谁在吃内存 | `ps -eo pid,rss,comm --sort=-rss`，前几行即大户 |
| 看单个进程占用 | `/proc/<pid>/status` 里的 `VmRSS` 与 `VmPeak` |

### 明确不要做的

- 不要用 `free -m` 的 `available` 列或 `free` 列下结论，量级不对。
- 不要用 `cat /proc/meminfo` 的 `MemTotal` 当总内存。
- 不要因为 `free` 显示只剩几十 MiB 就拒绝执行安装、编译、解压、起服务、跑数据管道。
- 不要因为 `memory.max` / `memory.limit_in_bytes` 是 200M 左右就认定环境只有 200M。这个值是弹性下限，突发时可以吃满 8 GiB。
- 反过来也别假设无限：`ΣRSS` 接近 8192 时就是真满了，此时必须降载，不是"还能再挤挤"。

### 内存吃紧时的处理顺序

1. 先定位占用：`ps -eo pid,rss,comm --sort=-rss | head -10`
2. 降并发：编译 `-j` 调小、下载分段、批处理分片、`xargs -P` 降到 1~2
3. 改流式：`while read` / `xargs -n` / 分块读写，替代一次性 `read()` 全量载入
4. 用完即释放：大数组 `del`、临时文件删掉、子进程 `wait` 回收
5. 仍然不够，才在交付物里写清峰值需求和分批方案

## 二、其他已知基线

以下为实测过的环境特征，用来避免重复试错。有疑义时以命令实测为准。

| 项 | 值 | 影响 |
|---|---|---|
| 发行版 | Debian 12 | `apt-get` 可用，`dpkg` 系参数 |
| 内核 | 6.6.x x86_64 | `epoll` / `inotify` / `io_uring` 可用 |
| 用户 | root | 不需要 `sudo` 前缀，`apt-get install` 直接跑 |
| 工作目录 | `/workspace` | 产物落这里，别往 `/root` 堆 |
| init | 非 systemd（`systemctl` 不可用） | **不要用 systemd unit / timer 做常驻** |
| cron | 常缺 `crontab` | **不要用 cron 做定时** |
| 常驻方式 | `setsid nohup cmd &` + pid 文件 | 进程自管，退出不自动重启 |

常驻脚本的写法：

```bash
setsid nohup python3 /path/daemon.py >>/path/daemon.log 2>&1 &
echo $! >/path/daemon.pid
```

停止时先核 `cmdline` 再 `kill`，别按进程名一把杀：

```bash
[ -n "$P" ] && [ -d "/proc/$P" ] && grep -q 'daemon.py' "/proc/$P/cmdline" 2>/dev/null && kill "$P"
```

## 三、资源类判断的执行顺序

涉及"这个环境能不能跑"的问题，按下面顺序取数，不要拿第一个数就下结论：

```bash
nproc                                    # CPU 核数
ps -eo rss= | awk '{s+=$1} END{printf "used=%dMiB\n", s/1024}'   # 已用
df -h /workspace                         # 磁盘余量
ulimit -n                                # 文件描述符上限
```

内存结论只看 `8192 − ΣRSS`，其余项按实测值报出，不做估算。
