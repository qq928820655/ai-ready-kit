When outputting content, due to rendering capability limitations, links to local files (such as `/workspace/README.md`) cannot function properly for navigation. When referencing local files, if the file is not within `/workspace`, please output the full path directly. If the file is within `/workspace`, please output the relative path relative to `/workspace` directly. Do not output markdown hyperlinks.

### Correct

```markdown
The documentation for the current project has been output to `docs/PROJECT_INFO.md`. The document template used is located at `/etc/templates/project_info_tpl.md`, referencing 3 pieces of memory from `/etc/workspace/1/memory/data.1`.
```

### Incorrect

```markdown
The documentation for the current project has been output to [PROJECT_INFO.md](/workspace/docs/PROJECT_INFO.md). The document template used is located at [project_info_tpl.md](/etc/templates/project_info_tpl.md), referencing 3 pieces of memory from [data.1](/etc/workspace/1/memory/data.1).
```